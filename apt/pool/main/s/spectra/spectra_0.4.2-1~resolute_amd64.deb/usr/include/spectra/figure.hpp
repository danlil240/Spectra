#pragma once

#include <functional>
#include <memory>
#include <spectra/axes.hpp>
#include <optional>
#include <spectra/fwd.hpp>
#include <spectra/style.hpp>
#include <spectra/window_defaults.hpp>
#include <string>
#include <string_view>
#include <vector>

namespace spectra
{

/// @brief Initial size of a Figure in pixels.
struct FigureConfig
{
    /// Figure width in pixels.
    uint32_t width = DEFAULT_WINDOW_WIDTH;
    /// Figure height in pixels.
    uint32_t height = DEFAULT_WINDOW_HEIGHT;
};

/// @brief Where the legend of each axes is drawn.
enum class LegendPosition
{
    TopRight,
    TopLeft,
    BottomRight,
    BottomLeft,
    None,
    Best,           // Corner with the least overlap with plotted data (default)
    OutsideRight,   // Right of the axes, top-aligned; the plot area shrinks to make room
};

/// @brief Legend placement and appearance for a Figure.
struct LegendConfig
{
    LegendPosition position  = LegendPosition::Best;
    bool           visible   = true;
    float          font_size = 0.0f;   ///< 0 = use default from font
    /// Legend fill.  Used when has_bg_color is true or its RGB is not black;
    /// otherwise (the default) the theme's legend colour is used.
    Color bg_color = {};
    /// Legend border.  Same rule as bg_color, with has_border_color.
    Color border_color = {};
    float padding      = 8.0f;
    /// Set to use bg_color / border_color even when it is pure black, which is
    /// otherwise read as "unset" for backward compatibility.
    bool has_bg_color     = false;
    bool has_border_color = false;

    /// True when the legend fill comes from bg_color rather than the theme.
    constexpr bool uses_bg_color() const
    {
        return has_bg_color || bg_color.r != 0.0f || bg_color.g != 0.0f || bg_color.b != 0.0f;
    }
    /// True when the legend border comes from border_color rather than the theme.
    constexpr bool uses_border_color() const
    {
        return has_border_color || border_color.r != 0.0f || border_color.g != 0.0f
               || border_color.b != 0.0f;
    }
};

/// @brief Which subplots of a Figure share an axis (Figure::share_x() / share_y()),
/// like matplotlib's ``subplots(sharex=...)``.
enum class ShareAxes : uint8_t
{
    None = 0,   ///< Every axes has its own limits (default)
    All  = 1,   ///< All 2D axes of the figure share the axis
    Row  = 2,   ///< Axes in the same grid row share the axis
    Col  = 3,   ///< Axes in the same grid column share the axis
};

/// @brief Figure background colour, outer margins and subplot spacing (pixels).
///
/// The margins are kept around the whole subplot grid; @ref subplot_hgap /
/// @ref subplot_vgap separate neighbouring plot areas.  With
/// @ref constrained_layout (default) the margins and gaps are minimums: they
/// grow so tick labels, axis labels and titles fit without overlapping a
/// neighbouring subplot or leaving the figure.
struct FigureStyle
{
    /// Figure background, used only when @ref background_override is true.
    Color background = colors::white;
    /// When false (default) the figure follows the active theme's canvas colour.
    bool  background_override = false;
    float margin_top          = 40.0f;
    float margin_bottom       = 60.0f;
    float margin_left         = 70.0f;
    float margin_right        = 20.0f;
    float subplot_hgap        = 40.0f;
    float subplot_vgap        = 50.0f;
    float min_subplot_height  = 150.0f;   ///< Minimum pixel height per subplot row
    /// Size margins and gaps from the measured labels (see above).  When false the
    /// grid uses the margins and gaps exactly.
    bool constrained_layout = true;
    /// Data palette for this figure's auto-coloured series (e.g. "colorblind");
    /// empty (default) follows the app's palette selection.
    std::string palette;
};

/// @brief Fluent builder that configures and starts a per-frame animation on a Figure.
///
/// Obtain one from Figure::animate():
/// @code
/// fig.animate().fps(60).on_frame([&](spectra::Frame& f) { /* update data */ }).play();
/// @endcode
class AnimationBuilder
{
   public:
    /// @brief Create a builder bound to @p fig.
    explicit AnimationBuilder(Figure& fig);

    /// @brief Target frame rate in frames per second (default 60).
    AnimationBuilder& fps(float target_fps);
    /// @brief Animation length in seconds; 0 runs until the window closes.
    AnimationBuilder& duration(float seconds);
    /// @brief Callback invoked once per frame before rendering.
    AnimationBuilder& on_frame(std::function<void(Frame&)> callback);
    /// @brief Restart the timeline when @ref duration is reached.
    AnimationBuilder& loop(bool enabled);

    /// @brief Start the animation in an interactive window.
    void play();
    /// @brief Render the animation offscreen and encode it to @p output_path (e.g. MP4).
    void record(const std::string& output_path);

   private:
    Figure&                     figure_;
    float                       target_fps_ = 60.0f;
    float                       duration_   = 0.0f;   ///< 0 = indefinite
    bool                        loop_       = false;
    std::function<void(Frame&)> on_frame_;
};

/// @brief Pending export requests (PNG / SVG / PDF / video).  Populated by Figure::save_*
/// and AnimationBuilder::record(); consumed by the runtime after rendering.
struct FigureExportRequest
{
    std::string png_path;
    uint32_t    png_width  = 0;   ///< 0 = use figure's native resolution
    uint32_t    png_height = 0;
    std::string png_theme;   ///< empty = active app theme
    bool        png_transparent   = false;
    bool        copy_to_clipboard = false;
    std::string svg_path;
    std::string svg_theme;   ///< empty = active app theme
    bool        svg_transparent = false;
    std::string pdf_path;
    std::string pdf_theme;   ///< empty = active app theme
    bool        pdf_transparent = false;
    std::string video_path;
};

/// @brief Optional settings for one Figure::save_png() / save_svg() / save_pdf() call.
struct ExportOptions
{
    uint32_t width  = 0;   ///< PNG width in pixels (0 = figure width); ignored for SVG / PDF
    uint32_t height = 0;   ///< PNG height in pixels (0 = figure height); ignored for SVG / PDF
    /// Theme this export is drawn with, e.g. "light" or "dark" (any registered
    /// theme name).  Empty uses the app's active theme.  Only this file is
    /// affected; an unknown name logs a warning and falls back to the active theme.
    std::string theme;
    /// Leave the figure background out: a PNG gets a transparent background
    /// (offscreen / headless rendering only; a capture of an on-screen window
    /// stays opaque), an SVG / PDF no background rectangle.
    bool transparent = false;
};

/// @brief Animation state set by AnimationBuilder, driven by WindowRuntime.
struct FigureAnimState
{
    float                       fps            = 60.0f;
    float                       duration       = 0.0f;
    bool                        loop           = false;
    bool                        live_streaming = false;
    std::function<void(Frame&)> on_frame;

    /// Per-figure elapsed time so each figure keeps its own timeline
    /// position even when it's not the active tab in a split view.
    float time = 0.0f;
};

/// @brief A canvas holding a grid of 2D and 3D axes; the top-level object you plot into.
///
/// Create figures through App::figure() (or spectra::figure() in the Easy API), add axes with
/// subplot() / subplot3d(), then display with App::run() or export with save_png().
class Figure
{
   public:
    /// @brief Construct a figure with the given size.
    explicit Figure(const FigureConfig& config = {});

    /// @brief Get or create the 2D axes at 1-based @p index in a @p rows x @p cols grid.
    Axes& subplot(int rows, int cols, int index);
    /// @brief Get or create the 3D axes at 1-based @p index in a @p rows x @p cols grid.
    Axes3D& subplot3d(int rows, int cols, int index);

    /// @brief Compute the subplot layout. Figures are displayed when App::run() runs.
    void show();
    /// @brief Request a PNG export at native resolution.
    ///
    /// Export calls only validate and queue the request; the file is written by
    /// the runtime after the figure is rendered (during / at the end of
    /// App::run()).  They return false — and queue nothing — when the path is
    /// empty, is a directory, or its parent directory is missing or not
    /// writable.  Later render/write failures are reported through the logger.
    bool save_png(const std::string& path);
    /// @brief Request a PNG export at the given resolution (see save_png()).
    bool save_png(const std::string& path, uint32_t export_width, uint32_t export_height);
    /// @brief Request a PNG export with per-export options (size, theme).
    bool save_png(const std::string& path, const ExportOptions& options);
    /// @brief Request an SVG vector export (see save_png() for the return value).
    bool save_svg(const std::string& path);
    /// @brief Request an SVG vector export with per-export options (theme).
    bool save_svg(const std::string& path, const ExportOptions& options);
    /// @brief Request a PDF vector export (see save_png() for the return value).
    bool save_pdf(const std::string& path);
    /// @brief Request a PDF vector export with per-export options (theme).
    bool save_pdf(const std::string& path, const ExportOptions& options);
    /// @brief Copy a rendered image of the figure to the system clipboard.
    void copy_to_clipboard();

    /// @brief Start configuring an animation for this figure.
    AnimationBuilder animate();

    /// @brief Figure width in pixels.
    uint32_t width() const { return config_.width; }
    /// @brief Figure height in pixels.
    uint32_t height() const { return config_.height; }
    /// @brief Resize the figure (pixels).
    void set_size(uint32_t w, uint32_t h)
    {
        config_.width  = w;
        config_.height = h;
    }

    /// Tab/window title set by user code (e.g. spectra::tab("Name")).
    /// When non-empty, the UI uses this as the tab/window display title
    /// instead of the auto-generated "Figure N".
    const std::string& tab_title() const { return tab_title_; }
    void               set_tab_title(std::string title) { tab_title_ = std::move(title); }

    /// @brief All 2D axes, in creation order.
    const std::vector<std::unique_ptr<Axes>>& axes() const { return axes_; }
    std::vector<std::unique_ptr<Axes>>&       axes_mut() { return axes_; }

    /// @brief All axes, including 3D ones.
    const std::vector<std::unique_ptr<AxesBase>>& all_axes() const { return all_axes_; }
    std::vector<std::unique_ptr<AxesBase>>&       all_axes_mut() { return all_axes_; }

    /// Return the 2D Axes at `index` if it exists, else nullptr.
    /// Checks axes() (2D) first, then all_axes() (3D/generic) with a dynamic_cast.
    Axes* get_axes(size_t index) const
    {
        if (index < axes_.size() && axes_[index])
            return axes_[index].get();
        if (index < all_axes_.size() && all_axes_[index])
            return dynamic_cast<Axes*>(all_axes_[index].get());
        return nullptr;
    }

    /// Iterate all axes (2D and 3D) and call fn(AxesBase*) for each non-null entry.
    template <typename Fn>
    void for_each_axes(Fn&& fn) const
    {
        for (auto& a : axes_)
            if (a)
                fn(static_cast<AxesBase*>(a.get()));
        for (auto& a : all_axes_)
            if (a)
                fn(a.get());
    }

    /// @brief Figure title drawn centred above the subplot grid (matplotlib's suptitle).
    /// An empty string removes it.
    void               suptitle(std::string_view text) { suptitle_ = std::string(text); }
    const std::string& suptitle() const { return suptitle_; }

    /// @brief Share the x axis between subplots (see ShareAxes): shared axes show
    /// the same x limits, autoscale to the data of the whole group, and only the
    /// bottom axes of a shared column draw x tick labels.  Applies to the 2D axes
    /// that exist now and to ones created later.
    void      share_x(ShareAxes mode);
    ShareAxes share_x() const { return share_x_; }
    /// @brief Share the y axis between subplots (see share_x()); only the left
    /// axes of a shared row draw y tick labels.
    void      share_y(ShareAxes mode);
    ShareAxes share_y() const { return share_y_; }

    /// @brief Turn on constrained layout (FigureStyle::constrained_layout), so the
    /// subplot spacing fits the labels.  Equivalent of matplotlib's tight_layout().
    void tight_layout() { style_.constrained_layout = true; }

    /// Where the suptitle is drawn (window / image pixels), set by the layout;
    /// zero-sized when there is none.
    const Rect& suptitle_rect() const { return suptitle_rect_; }
    void        set_suptitle_rect(const Rect& r) { suptitle_rect_ = r; }

    /// @brief Mutable figure style (background, margins, gaps).
    FigureStyle&       style() { return style_; }
    const FigureStyle& style() const { return style_; }
    /// @brief Apply a plot style (see StyleSheet) to the figure and all its axes.
    /// Axes created later by subplot() / subplot3d() get it as well.
    void apply_style(const StyleSheet& style);
    /// @brief Apply the built-in style @p name ("default", "paper", "talk",
    /// "minimal", "dark-paper").  Returns false (and changes nothing) for an
    /// unknown name.
    bool apply_style(std::string_view name);
    /// @brief The style last applied, or nullopt when none was.
    const std::optional<StyleSheet>& style_sheet() const { return style_sheet_; }
    /// @brief Record @p style as the figure's style without applying it (undo,
    /// file loading): only axes created later by subplot() use it.
    void set_style_sheet(std::optional<StyleSheet> style) { style_sheet_ = std::move(style); }
    /// @brief Name of the style last applied; empty when none was.
    std::string style_name() const { return style_sheet_ ? style_sheet_->name : std::string(); }

    /// @brief Mutable legend configuration.
    LegendConfig&       legend() { return legend_; }
    const LegendConfig& legend() const { return legend_; }

    // Layout: called by renderer before drawing
    /// @brief Recompute axes viewports from the subplot grid (called by the renderer).
    void compute_layout();

    // Subplot grid info
    /// @brief Number of subplot grid rows.
    int grid_rows() const { return grid_rows_; }
    /// @brief Number of subplot grid columns.
    int grid_cols() const { return grid_cols_; }

    /// Scroll state for overflowing subplot grids
    float scroll_offset_y() const { return scroll_offset_y_; }
    void  set_scroll_offset_y(float offset) { scroll_offset_y_ = offset; }
    float content_height() const { return content_height_; }
    void  set_content_height(float h) { content_height_ = h; }
    bool  needs_scroll(float visible_height) const
    {
        return content_height_ > visible_height + 0.5f;
    }

    /// Explicitly set grid dimensions (e.g. after removing rows/cols).
    void set_grid(int rows, int cols)
    {
        if (rows >= 1)
            grid_rows_ = rows;
        if (cols >= 1)
            grid_cols_ = cols;
    }

    // Animation property accessors
    /// @brief Target animation frame rate.
    float anim_fps() const { return anim_.fps; }
    float anim_duration() const { return anim_.duration; }
    bool  anim_loop() const { return anim_.loop; }
    /// @brief True if a frame callback or live streaming is active.
    bool has_animation() const { return static_cast<bool>(anim_.on_frame) || anim_.live_streaming; }

    /// Export / animation sub-objects (public so runtime subsystems can
    /// consume pending requests without requiring friend access).
    FigureExportRequest export_req_;
    FigureAnimState     anim_;

   private:
    // Re-group the 2D axes for share_x_ / share_y_ (called when a mode is set
    // and when a subplot is created).
    void apply_share_modes(bool x, bool y);

    friend class AnimationBuilder;
    friend class App;
    friend class FigureManager;
    friend class WindowRuntime;
    friend class SessionRuntime;
    friend class FigureSerializer;
    friend class EmbedSurface;

    FigureConfig                           config_;
    FigureStyle                            style_;
    std::optional<StyleSheet>              style_sheet_;
    LegendConfig                           legend_;
    std::vector<std::unique_ptr<Axes>>     axes_;
    std::vector<std::unique_ptr<AxesBase>> all_axes_;
    int                                    grid_rows_ = 1;
    int                                    grid_cols_ = 1;

    /// Scroll state for overflow when subplots exceed visible area
    float       scroll_offset_y_ = 0.0f;
    float       content_height_  = 0.0f;
    std::string tab_title_;
    std::string suptitle_;
    Rect        suptitle_rect_{0.0f, 0.0f, 0.0f, 0.0f};
    ShareAxes   share_x_ = ShareAxes::None;
    ShareAxes   share_y_ = ShareAxes::None;
};

}   // namespace spectra

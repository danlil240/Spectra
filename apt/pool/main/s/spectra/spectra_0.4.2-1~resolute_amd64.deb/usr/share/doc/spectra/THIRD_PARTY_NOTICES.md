# Third-Party Notices

Spectra is licensed under the MIT License (see [`LICENSE`](LICENSE)). It
includes, fetches at build time, or redistributes the third-party components
listed below. Each component remains under its own license; full license texts
are in [`licenses/`](licenses/). Installs and CPack packages place this file,
`LICENSE` and `licenses/` under `share/doc/spectra/`.

How a component reaches you:

- **vendored**: the source is committed under `third_party/`.
- **fetched**: CMake `FetchContent` downloads it at configure time, pinned to
  the tag listed, and it is compiled into Spectra's libraries/executables.
  Where a `SPECTRA_USE_SYSTEM_<DEP>` option exists, a system copy can be used
  instead (see `BUILD_ENVIRONMENT.md`). In that case the system package's own
  license applies and Spectra does not redistribute it.
- **embedded asset**: font data is compiled into the binaries and/or installed
  under `share/spectra/fonts/`.

## Redistributed components

| Component | Version | License | How it is included | Upstream |
|-----------|---------|---------|--------------------|----------|
| Dear ImGui (docking branch) | v1.92.6-docking | MIT | fetched, compiled into `libspectra` | https://github.com/ocornut/imgui |
| ↳ ProggyClean / ProggyForever fonts (inside ImGui) | as shipped with ImGui | MIT | compiled into `libspectra` (ImGui default font) | https://github.com/ocornut/proggyforever |
| GLFW | 3.4 | zlib | fetched (default when no system GLFW >= 3.3 is found); installed as `lib/spectra/libglfw3.a` (`spectra::glfw`) | https://github.com/glfw/glfw |
| FlatBuffers | v25.2.10 | Apache-2.0 | fetched; runtime headers compiled into `libspectra`; generated C++ (build tree) and Python (`python/spectra/_fb_generated/`) code | https://github.com/google/flatbuffers |
| SDL | 3.2.0 | zlib | fetched, optional (`SPECTRA_USE_SDL3=ON` only) | https://github.com/libsdl-org/SDL |
| Vulkan Memory Allocator | 3.4.0 | MIT | vendored (`third_party/vma/`) | https://github.com/GPUOpen-LibrariesAndSDKs/VulkanMemoryAllocator |
| stb_image | 2.30 | MIT or Public Domain (Unlicense), at your choice | vendored (`third_party/stb/`) | https://github.com/nothings/stb |
| stb_image_write | 1.16 | MIT or Public Domain (Unlicense), at your choice | vendored (`third_party/stb/`) | https://github.com/nothings/stb |
| stb_truetype | 1.26 | MIT or Public Domain (Unlicense), at your choice | vendored (`third_party/stb/`) | https://github.com/nothings/stb |
| nlohmann/json | 3.11.3 | MIT | vendored (`third_party/nlohmann/`) | https://github.com/nlohmann/json |
| foxglove/mcap (C++ library, header-only) | releases/cpp/v2.1.2 | MIT | fetched (`SPECTRA_USE_MCAP=ON`, default), compiled into `libspectra-core` for the MCAP log reader | https://github.com/foxglove/mcap |
| tinyfiledialogs | 3.21.3 | zlib | vendored (`third_party/tinyfiledialogs.*`) | https://sourceforge.net/projects/tinyfiledialogs/ |
| Inter (Regular, 4.001) | 4.001 | SIL OFL 1.1 | embedded asset (`third_party/Inter-Regular.ttf`, installed to `share/spectra/fonts/`, embedded into `libspectra`) | https://github.com/rsms/inter |
| Inter (variable, InterVariable.ttf) | 4.x | SIL OFL 1.1 | embedded asset (`third_party/inter_font.hpp`) | https://github.com/rsms/inter |
| Inter SemiBold (UI-range subset of Inter-SemiBold.otf) | 4.0 | SIL OFL 1.1 | embedded asset (`third_party/inter_semibold_font.hpp`, UI headings and titles) | https://github.com/rsms/inter |
| Font Awesome Free (Solid 900) | 6.5.1 | Font: SIL OFL 1.1; icons: CC BY 4.0; code: MIT | embedded asset (`third_party/fa_solid_900.hpp`) | https://github.com/FortAwesome/Font-Awesome |
| DejaVu Sans (symbol subset) | 2.37 | Bitstream Vera license (DejaVu changes public domain) | embedded asset (`third_party/fonts/DejaVuSans-Symbols.ttf`, embedded into Emscripten/browser builds only as the symbol fallback font) | https://dejavu-fonts.github.io/ |
| matplotlib colormap data (viridis, plasma, inferno, magma, cividis, turbo, twilight, coolwarm, RdBu, PuOr, jet, gray, hot) | 3.11.2 | Matplotlib License (PSF-based); viridis family CC0 1.0; turbo Apache-2.0 (Google); RdBu/PuOr ColorBrewer Apache-2.0 | generated lookup tables compiled into `libspectra` (`src/core/colormap_tables.hpp`, by `tools/gen_colormap_tables.py`) | https://matplotlib.org |

## Build-time / test-only components (not redistributed)

| Component | Version | License | Use | Upstream |
|-----------|---------|---------|-----|----------|
| GoogleTest | v1.14.0 | BSD-3-Clause | fetched for unit tests (`SPECTRA_BUILD_TESTS`) | https://github.com/google/googletest |
| Google Benchmark | v1.8.3 | Apache-2.0 | fetched for benchmarks (`SPECTRA_BUILD_BENCHMARKS`) | https://github.com/google/benchmark |
| Vulkan-Headers | v1.3.275 | Apache-2.0 | fetched for Emscripten/WebGPU builds only (headers) | https://github.com/KhronosGroup/Vulkan-Headers |

## System dependencies (not bundled)

These are found on the build machine and are not shipped by Spectra. Their
own licenses apply: the Vulkan loader (Apache-2.0), Eigen 3 (MPL-2.0,
optional, header-only, used through `spectra/eigen.hpp`), FFmpeg (run as
an external `ffmpeg` process for video export, not linked), Qt 6 (LGPL-3.0 /
commercial, optional adapter), ROS 2 (Apache-2.0, optional adapter), Dawn
(BSD-3-Clause, optional WebGPU backend).

## Spectra's own assets

`third_party/SpectraIcons.ttf`, `SpectraIcons.otf`, `icon_font_data.hpp`
(generated by `tools/generate_icon_font.py`) and the images in `icons/`
are original Spectra artwork under Spectra's MIT License.

## License texts

| File | Applies to |
|------|------------|
| [`licenses/ImGui-LICENSE.txt`](licenses/ImGui-LICENSE.txt) | Dear ImGui (MIT) |
| [`licenses/GLFW-LICENSE.md`](licenses/GLFW-LICENSE.md) | GLFW (zlib) |
| [`licenses/FlatBuffers-LICENSE.txt`](licenses/FlatBuffers-LICENSE.txt) | FlatBuffers (Apache License 2.0, full text) |
| [`licenses/SDL3-LICENSE.txt`](licenses/SDL3-LICENSE.txt) | SDL 3 (zlib) |
| [`licenses/VulkanMemoryAllocator-LICENSE.txt`](licenses/VulkanMemoryAllocator-LICENSE.txt) | Vulkan Memory Allocator (MIT) |
| [`licenses/stb-LICENSE.txt`](licenses/stb-LICENSE.txt) | stb (MIT / Public Domain) |
| [`licenses/nlohmann-json-LICENSE.MIT`](licenses/nlohmann-json-LICENSE.MIT) | nlohmann/json (MIT) |
| [`licenses/foxglove-mcap-LICENSE.txt`](licenses/foxglove-mcap-LICENSE.txt) | foxglove/mcap (MIT) |
| [`licenses/tinyfiledialogs-LICENSE.txt`](licenses/tinyfiledialogs-LICENSE.txt) | tinyfiledialogs (zlib) |
| [`licenses/Inter-OFL.txt`](licenses/Inter-OFL.txt) | Inter (SIL OFL 1.1) |
| [`licenses/FontAwesome-Free-LICENSE.txt`](licenses/FontAwesome-Free-LICENSE.txt) | Font Awesome Free (OFL 1.1 fonts, CC BY 4.0 icons, MIT code) |
| [`licenses/DejaVu-LICENSE.txt`](licenses/DejaVu-LICENSE.txt) | DejaVu Sans symbol subset (Bitstream Vera license) |
| [`licenses/matplotlib-LICENSE.txt`](licenses/matplotlib-LICENSE.txt) | matplotlib colormap data (Matplotlib License; ColorBrewer notice; per-map notes) |

Font Awesome attribution (CC BY 4.0): icons by Fonticons, Inc.,
https://fontawesome.com, licensed under CC BY 4.0
(https://creativecommons.org/licenses/by/4.0/).

When you update a component, update its row here, the pinned tag in CMake,
and its file in `licenses/`.

#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "spectra::spectra-core" for configuration "Release"
set_property(TARGET spectra::spectra-core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(spectra::spectra-core PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libspectra-core.a"
  )

list(APPEND _cmake_import_check_targets spectra::spectra-core )
list(APPEND _cmake_import_check_files_for_spectra::spectra-core "${_IMPORT_PREFIX}/lib/libspectra-core.a" )

# Import target "spectra::spectra" for configuration "Release"
set_property(TARGET spectra::spectra APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(spectra::spectra PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libspectra.a"
  )

list(APPEND _cmake_import_check_targets spectra::spectra )
list(APPEND _cmake_import_check_files_for_spectra::spectra "${_IMPORT_PREFIX}/lib/libspectra.a" )

# Import target "spectra::glfw" for configuration "Release"
set_property(TARGET spectra::glfw APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(spectra::glfw PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/spectra/libglfw3.a"
  )

list(APPEND _cmake_import_check_targets spectra::glfw )
list(APPEND _cmake_import_check_files_for_spectra::glfw "${_IMPORT_PREFIX}/lib/spectra/libglfw3.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

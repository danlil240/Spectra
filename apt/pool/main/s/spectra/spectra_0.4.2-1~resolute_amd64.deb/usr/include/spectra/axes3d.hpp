#pragma once

#include <algorithm>
#include <memory>
#include <spectra/axes.hpp>
#include <spectra/camera.hpp>
#include <spectra/fwd.hpp>
#include <spectra/math3d.hpp>
#include <spectra/series3d.hpp>
#include <spectra/series_shapes3d.hpp>
#include <string>
#include <vector>

namespace spectra
{

// How the 3D axes box is drawn (Axes3D::box_style).
enum class BoxStyle
{
    Back,   // the three back panes (with the grid) plus the edges that carry ticks
    Full,   // all twelve box edges
    None,   // no box edges
};

// Where the 3D key light comes from (Axes3D::light_mode).
enum class LightMode
{
    Fixed,       // light_dir(): a direction fixed to the data axes
    Headlight,   // from the camera: faces towards the viewer are always lit
};

class Axes3D : public AxesBase
{
   public:
    Axes3D();
    ~Axes3D();

    void xlim(double min, double max);
    void ylim(double min, double max);
    void zlim(double min, double max);

    void xlabel(const std::string& lbl);
    void ylabel(const std::string& lbl);
    void zlabel(const std::string& lbl);

    // Effective limits: the set (or auto-fit) limits, widened about their
    // centres to a common span when equal_aspect() is on.
    AxisLimits x_limits() const;
    AxisLimits y_limits() const;
    AxisLimits z_limits() const;

    // Equal aspect ("axis equal"): one data unit has the same length along
    // X, Y and Z.  The box keeps its cube shape; each axis range is widened
    // about its centre to the largest of the three spans, so a sphere looks
    // round and a flat trajectory looks flat.  Off by default.
    void equal_aspect(bool enabled) { equal_aspect_ = enabled; }
    bool equal_aspect() const { return equal_aspect_; }

    const std::string& xlabel() const { return xlabel_; }
    const std::string& ylabel() const { return ylabel_; }
    const std::string& zlabel() const { return zlabel_; }

    // Deprecated aliases
    const std::string& get_xlabel() const { return xlabel_; }
    const std::string& get_ylabel() const { return ylabel_; }
    const std::string& get_zlabel() const { return zlabel_; }

    TickResult compute_x_ticks() const;
    TickResult compute_y_ticks() const;
    TickResult compute_z_ticks() const;

    void auto_fit() override;

    Camera&       camera() { return *camera_; }
    const Camera& camera() const { return *camera_; }

    enum class GridPlane
    {
        None = 0,
        XY   = 1 << 0,
        XZ   = 1 << 1,
        YZ   = 1 << 2,
        All  = XY | XZ | YZ
    };

    // UI highlight for axis-arrow hover (drives brighter arrow rendering).
    enum class AxisArrowHover
    {
        None,
        X,
        Y,
        Z
    };

    void           set_hovered_axis_arrow(AxisArrowHover hover) { hovered_axis_arrow_ = hover; }
    AxisArrowHover hovered_axis_arrow() const { return hovered_axis_arrow_; }

    void      grid_planes(GridPlane planes) { grid_planes_ = static_cast<int>(planes); }
    GridPlane grid_planes() const { return static_cast<GridPlane>(grid_planes_); }

    // Deprecated: use grid_planes(GridPlane) instead
    void set_grid_planes(int planes) { grid_planes_ = planes; }

    // Box edges: Back (default) draws the three back panes -- the grid planes
    // always sit on the faces farthest from the camera -- plus the three edges
    // that carry the ticks; Full draws all twelve edges; None hides the box.
    void box_style(BoxStyle style)
    {
        box_style_ = style;
        if (style != BoxStyle::None)
            visible_box_style_ = style;
    }
    BoxStyle box_style() const { return box_style_; }

    // Shorthand: false hides the box (BoxStyle::None), true restores the last
    // visible style (BoxStyle::Back by default).
    bool show_bounding_box() const { return box_style_ != BoxStyle::None; }
    void show_bounding_box(bool enabled)
    {
        box_style_ = enabled ? visible_box_style_ : BoxStyle::None;
    }

    // Directional light configuration
    void light_dir(float x, float y, float z) { light_dir_ = {x, y, z}; }
    void light_dir(vec3 dir) { light_dir_ = dir; }
    vec3 light_dir() const { return light_dir_; }

    void lighting_enabled(bool enabled) { lighting_enabled_ = enabled; }
    bool lighting_enabled() const { return lighting_enabled_; }

    // Fixed (default) lights along light_dir(); Headlight follows the camera,
    // like MATLAB's camlight headlight, so the side being looked at stays lit
    // while orbiting.
    void      light_mode(LightMode mode) { light_mode_ = mode; }
    LightMode light_mode() const { return light_mode_; }

    // light_dir() as azimuth (degrees from +X towards +Y) and elevation
    // (degrees above the XY plane), like MATLAB's lightangle.
    void  light_angles(float azimuth_deg, float elevation_deg);
    float light_azimuth() const;
    float light_elevation() const;

    // Fog: every 3D series fades towards the plot background with distance
    // from the camera; 0 (default) is off, 1 the strongest.  A depth cue for
    // lines, surfaces and meshes (scatter points have their own
    // ScatterSeries3D::depth_shade, on by default).
    void  fog(float strength) { fog_ = std::clamp(strength, 0.0f, 1.0f); }
    float fog() const { return fog_; }

    // Deprecated aliases
    void set_light_dir(float x, float y, float z) { light_dir_ = {x, y, z}; }
    void set_light_dir(vec3 dir) { light_dir_ = dir; }
    void set_lighting_enabled(bool enabled) { lighting_enabled_ = enabled; }

    // Returns a model matrix that maps data coordinates [xlim, ylim, zlim]
    // into a fixed-size normalized cube [-box_half_size, +box_half_size]³.
    // This keeps the bounding box a constant visual size regardless of zoom.
    mat4 data_to_normalized_matrix() const;

    // The half-size of the fixed normalized bounding box in world units.
    static constexpr float box_half_size() { return 3.0f; }

    // Factor (>= 1) by which the camera projection is widened in viewport `vp`
    // so the bounding box fits the viewport (plus a small proportional bleed
    // into the surrounding layout margin, where labels, arrows and the title
    // go) at the default camera distance.  1 for landscape viewports; only
    // narrow ones zoom out.  Depends only on the viewport's aspect ratio -- not
    // on its pixel size, DPI, orientation, zoom or FOV -- so the box keeps a
    // steady size while orbiting.
    float projection_fit_scale(const Rect& vp) const;

    // Camera projection for viewport `vp` with projection_fit_scale() applied.
    mat4 projection_matrix(const Rect& vp) const;

    // Zoom by scaling axis limits (bounding box stays fixed, data range changes)
    void zoom_limits(float factor);

    // Zoom a single axis only (for right-click 1D zoom)
    void zoom_limits_x(float factor);
    void zoom_limits_y(float factor);
    void zoom_limits_z(float factor);

    // Pan by shifting axis limits (bounding box stays fixed, data range shifts)
    // dx_screen/dy_screen are pixel deltas, vp_w/vp_h are viewport dimensions.
    void pan_limits(float dx_screen, float dy_screen, float vp_w, float vp_h);

    LineSeries3D&    line3d(std::span<const float> x,
                            std::span<const float> y,
                            std::span<const float> z);
    ScatterSeries3D& scatter3d(std::span<const float> x,
                               std::span<const float> y,
                               std::span<const float> z);
    SurfaceSeries&   surface(std::span<const float> x_grid,
                             std::span<const float> y_grid,
                             std::span<const float> z_values);
    MeshSeries&      mesh(std::span<const float> vertices, std::span<const uint32_t> indices);
    ShapeSeries3D&   shapes3d();

   private:
    // Padded bounding box of all series data (what auto_fit() would set).
    // Returns false when there is no data.  Used for axes whose limits were
    // never set explicitly, so headless/offscreen renders frame the data
    // the same way an interactive auto-fit does.
    bool compute_auto_limits(vec3& lo, vec3& hi) const;

    // Limits before equal_aspect() is applied.
    AxisLimits raw_x_limits() const;
    AxisLimits raw_y_limits() const;
    AxisLimits raw_z_limits() const;
    // Applies equal_aspect() to the raw limits of axis 0 (x), 1 (y) or 2 (z).
    AxisLimits effective_limits(int axis) const;

    std::optional<AxisLimits> xlim_;
    std::optional<AxisLimits> ylim_;
    std::optional<AxisLimits> zlim_;

    std::string xlabel_;
    std::string ylabel_;
    std::string zlabel_;

    std::unique_ptr<Camera> camera_;
    int                     grid_planes_        = static_cast<int>(GridPlane::All);
    BoxStyle                box_style_          = BoxStyle::Back;
    BoxStyle                visible_box_style_  = BoxStyle::Back;
    vec3                    light_dir_          = {1.0f, 1.0f, 1.0f};   // Default: top-right-front
    bool                    lighting_enabled_   = true;
    LightMode               light_mode_         = LightMode::Fixed;
    float                   fog_                = 0.0f;
    bool                    equal_aspect_       = false;
    AxisArrowHover          hovered_axis_arrow_ = AxisArrowHover::None;
};

inline Axes3D::GridPlane operator|(Axes3D::GridPlane a, Axes3D::GridPlane b)
{
    return static_cast<Axes3D::GridPlane>(static_cast<int>(a) | static_cast<int>(b));
}

inline Axes3D::GridPlane operator&(Axes3D::GridPlane a, Axes3D::GridPlane b)
{
    return static_cast<Axes3D::GridPlane>(static_cast<int>(a) & static_cast<int>(b));
}

inline Axes3D::GridPlane operator~(Axes3D::GridPlane a)
{
    return static_cast<Axes3D::GridPlane>(~static_cast<int>(a));
}

}   // namespace spectra

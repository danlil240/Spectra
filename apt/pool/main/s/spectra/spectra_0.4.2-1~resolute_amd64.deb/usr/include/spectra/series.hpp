#pragma once

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <functional>
#include <memory>
#include <span>
#include <spectra/color.hpp>
#include <spectra/colormap.hpp>
#include <spectra/fwd.hpp>
#include <spectra/plot_style.hpp>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

namespace spectra
{

class PendingSeriesData;

namespace detail
{
// True for the double-precision append()/erase_*() overloads: every argument
// is arithmetic and at least one is double or long double.  Calls with only
// float/integer arguments keep using the float overloads, so existing calls
// such as append(i, 2.0f) or append(1, 2) behave exactly as before.
template <typename T>
inline constexpr bool is_wide_float_v = std::is_floating_point_v<T> && (sizeof(T) > sizeof(float));

template <typename... Ts>
inline constexpr bool wants_f64_overload_v =
    (std::is_arithmetic_v<Ts> && ...) && (is_wide_float_v<Ts> || ...);
}   // namespace detail

// Custom deleter for PendingSeriesData (allows incomplete type in unique_ptr).
struct PendingSeriesDataDeleter
{
    void operator()(PendingSeriesData* ptr) const;
};

/// @brief Basic visual style of a series.
struct SeriesStyle
{
    Color color      = colors::blue;
    float line_width = 2.0f;
    float point_size = 4.0f;
    float opacity    = 1.0f;
};

/// @brief Axis-aligned rectangle in pixels (x, y = top-left corner).
struct Rect
{
    float x = 0.0f;
    float y = 0.0f;
    float w = 0.0f;
    float h = 0.0f;
};

/// Series "needs GPU upload" flag that also records a new generation each time
/// it is raised.  The renderer clears the flag after each upload; the
/// generation stays, so caches derived from series data (e.g. the axes'
/// autoscale extent) can tell that anything changed since they were filled.
class SeriesDirtyFlag
{
   public:
    SeriesDirtyFlag(bool v = true) : flag_(v), generation_(next_generation()) {}
    SeriesDirtyFlag(const SeriesDirtyFlag&)            = delete;
    SeriesDirtyFlag& operator=(const SeriesDirtyFlag&) = delete;

    SeriesDirtyFlag& operator=(bool v)
    {
        store(v);
        return *this;
    }
    operator bool() const { return load(); }

    bool load(std::memory_order order = std::memory_order_seq_cst) const
    {
        return flag_.load(order);
    }
    void store(bool v, std::memory_order order = std::memory_order_seq_cst)
    {
        if (v)
            generation_.store(next_generation(), std::memory_order_relaxed);
        flag_.store(v, order);
    }
    std::uint64_t generation() const { return generation_.load(std::memory_order_relaxed); }
    /// Raises the flag but keeps the generation: for changes derived from the
    /// environment (theme colours resolved while drawing), not from the content.
    void raise_same_generation() { flag_.store(true); }

   private:
    // Process-wide counter: a generation is never reused, even by a new
    // series that lands at the address of a removed one.
    static std::uint64_t next_generation();

    std::atomic<bool>          flag_;
    std::atomic<std::uint64_t> generation_;
};

/// @brief Base class of everything that can be drawn in an axes.
///
/// Setters return a reference so calls can be chained, e.g.
/// `ax.plot(x, y).label("signal").color(spectra::colors::red);`
class Series
{
   public:
    virtual ~Series();

    Series() = default;

    /// Move operations — deleted because std::atomic<bool> is not movable.
    /// Series instances are managed by pointer/reference; moves are not needed.
    Series(Series&&)            = delete;
    Series& operator=(Series&&) = delete;

    /// Copy operations — pending buffer is NOT copied (thread-safe state
    /// is per-instance and must be re-enabled on copies).
    Series(const Series& other);
    Series& operator=(const Series& other);

    /// @brief Set the legend label.
    Series& label(const std::string& lbl)
    {
        label_ = lbl;
        return *this;
    }
    /// @brief Set the series colour.  An explicit colour disables automatic
    /// palette colouring (see has_auto_color()).
    Series& color(const Color& c)
    {
        set_color(c);
        return *this;
    }
    /// @brief Show or hide the series.
    Series& visible(bool v)
    {
        visible_ = v;
        return *this;
    }

    /// @brief Legend label.
    const std::string& label() const { return label_; }
    /// @brief Series colour.
    ///
    /// For an auto-coloured series (has_auto_color()) this is the colour of its
    /// palette slot in the active theme's data palette, as resolved at the last
    /// draw.  Before the first draw (or without a UI theme) it is the slot's
    /// colour in palette::default_cycle.
    const Color& color() const { return color_; }

    /// @brief True when the colour follows the theme's data palette, i.e. no
    /// colour was set explicitly (via color(), set_color(), a format string or
    /// a PlotStyle with a colour).
    bool has_auto_color() const { return auto_color_index_ >= 0; }
    /// @brief Palette slot used for automatic colouring, or -1 for an explicit colour.
    int auto_color_index() const { return auto_color_index_; }
    /// @brief Make the colour follow palette slot @p index (negative: keep the
    /// current colour as an explicit one).  Called by Axes / Axes3D when a
    /// series is created; sets the provisional colour from palette::default_cycle.
    void set_auto_color_index(int index);
    /// @brief Set the resolved palette colour of an auto-coloured series.
    /// No-op for an explicitly coloured series.  Returns true if the colour changed.
    bool resolve_auto_color(const Color& c);

    /// @brief MATLAB colour letter (r g b c m y k w) the colour was set from by
    /// a format string, or '\0'.  Such a colour is a tuned shade that the
    /// renderer re-resolves for the active theme (format_colors::shade()).
    char color_letter() const { return color_letter_; }
    /// @brief Colour the series with the tuned shade of format letter @p letter
    /// (dark-background shade until the next draw).  A non-letter keeps the
    /// current colour as an explicit one.
    void set_color_letter(char letter);
    /// @brief Set the resolved shade of a letter-coloured series.  No-op for
    /// other series.  Returns true if the colour changed.
    bool resolve_letter_color(const Color& c);
    /// @brief Whether the series is drawn.
    bool visible() const { return visible_; }

    /// Reference lines (hline/vline) are excluded from autoscale calculations
    /// so their large span does not pollute axis limits.
    bool excluded_from_autoscale() const { return excluded_from_autoscale_; }
    void set_excluded_from_autoscale(bool v) { excluded_from_autoscale_ = v; }

    // ── Double-precision x-axis offset ──
    /// Logical x value = x_offset() + x_data()[i].  Allows plotting data with
    /// large absolute x values (e.g. epoch timestamps ~1.7e9) that exceed
    /// float's ~7-digit precision: the stored floats stay small and precise
    /// while axis limits, ticks, and cursor readouts show absolute values.
    Series& x_offset(double off)
    {
        x_offset_ = off;
        dirty_    = true;
        return *this;
    }
    double x_offset() const { return x_offset_; }

    /// Logical y value = y_offset() + y_data()[i].  Same idea as x_offset() for
    /// data such as 1e7 + small variations, where float storage would quantise
    /// the signal into visible stairs.  The double-precision set_y() overloads
    /// choose this automatically.
    Series& y_offset(double off)
    {
        y_offset_ = off;
        dirty_    = true;
        return *this;
    }
    double y_offset() const { return y_offset_; }

    /// @brief Data binding URI: where the series' data comes from, e.g.
    /// "topic://imu/accel_x" or "csv://flight.csv?x=time#accel_x" (see
    /// docs/layouts.md).  Empty when the data was set directly.  Saved by
    /// File > Save Layout so the layout can be reopened against other data.
    const std::string& data_binding() const { return data_binding_; }
    void               set_data_binding(std::string uri) { data_binding_ = std::move(uri); }

    /// Control whether this series appears in the legend.
    bool show_in_legend() const { return show_in_legend_; }
    void set_show_in_legend(bool v) { show_in_legend_ = v; }

    /// True for Axes::hline / Axes::vline reference lines (not general legend hiding).
    bool is_reference_line() const { return is_reference_line_; }
    void set_reference_line(bool v) { is_reference_line_ = v; }

    /// @brief True when the series changed since the last GPU upload.
    bool is_dirty() const { return dirty_; }
    /// Changes every time the series is marked dirty (data, offsets or
    /// style) and survives clear_dirty().  For caches keyed on series content.
    std::uint64_t change_generation() const { return dirty_.generation(); }
    void          clear_dirty() { dirty_ = false; }
    void          mark_dirty();

    /// Process-unique id of this series object, never reused (unlike its
    /// address); a copy gets a new one.  Lets long-lived references such as
    /// undo entries tell whether the series they captured still exists.
    std::uint64_t instance_id() const { return instance_id_; }

    // ── Thread-safe data access (opt-in) ──
    /// When enabled, set_x/set_y/append/erase_before route through a pending
    /// buffer that is committed atomically at frame boundary.  Default off
    /// (zero overhead for single-threaded callers).
    void set_thread_safe(bool enabled);
    bool is_thread_safe() const { return thread_safe_; }

    /// Apply pending data from background threads.  Called by SessionRuntime
    /// at frame boundary.  Returns true if data was committed.
    virtual bool commit_pending();

    /// Set a callback invoked when background data arrives (for waking idle loops).
    void set_wake_fn(std::function<void()> fn);
    /// @brief Set the colour (non-fluent form).
    void set_color(const Color& c)
    {
        color_            = c;
        auto_color_index_ = -1;
        color_letter_     = '\0';
        dirty_            = true;
    }

    // ── Event system integration ──
    /// Called by AxesBase when the series is added to axes with an event system.
    void set_event_context(EventSystem* es, AxesBase* axes)
    {
        event_system_ = es;
        owning_axes_  = axes;
    }

    // ── Plot style (line style, marker style, etc.) ──
    /// @brief Set the line style (solid, dashed, ...).
    Series& line_style(LineStyle s)
    {
        style_.line_style = s;
        dirty_            = true;
        return *this;
    }
    /// @brief Set the marker shape.
    Series& marker_style(MarkerStyle s)
    {
        style_.marker_style = s;
        dirty_              = true;
        return *this;
    }
    /// @brief Set the marker size in pixels.
    Series& marker_size(float s)
    {
        style_.marker_size = s;
        dirty_             = true;
        return *this;
    }
    /// @brief Set opacity in [0, 1].
    Series& opacity(float o)
    {
        style_.opacity = o;
        dirty_         = true;
        return *this;
    }
    /// @brief Apply a complete PlotStyle.
    Series& plot_style(const PlotStyle& ps);

    LineStyle        line_style() const { return style_.line_style; }
    MarkerStyle      marker_style() const { return style_.marker_style; }
    float            marker_size() const { return style_.marker_size; }
    float            opacity() const { return style_.opacity; }
    const PlotStyle& plot_style() const { return style_; }
    PlotStyle&       plot_style_mut() { return style_; }

    // ── Streaming data interface (optional; implemented by LineSeries / ChunkedLineSeries) ──
    /// @brief Append one point (streaming series only).
    ///
    /// The float form stores (x, y) as given, i.e. relative to x_offset() /
    /// y_offset().
    virtual void append(float /*x*/, float /*y*/) {}

    /// @brief Append one point given in absolute, double-precision values.
    ///
    /// Chosen whenever either argument is a double (e.g. append(t, 1.5) with
    /// a double timestamp t); calls with only float/integer arguments use the
    /// float form above.  The point is stored as float offsets from
    /// x_offset()/y_offset(), so data such as Unix timestamps or 1e7 + small
    /// variations keeps its precision.  When the first such point goes into
    /// an empty series that has no offset yet, a value of magnitude >= 1000
    /// becomes the offset (smaller values keep offset 0 and are stored as is).
    template <typename X, typename Y>
        requires detail::wants_f64_overload_v<X, Y>
    void append(X x, Y y)
    {
        append_f64(static_cast<double>(x), static_cast<double>(y));
    }

    /// @brief Remove points with x below a threshold; returns how many were removed.
    ///
    /// The float form compares against the stored values (relative to
    /// x_offset()); a double threshold (see append(double, double)) is an
    /// absolute x value.
    virtual size_t erase_before(float /*x_threshold*/) { return 0; }
    /// @brief Remove points with x below an absolute double x; see erase_before(float).
    template <typename T>
        requires detail::wants_f64_overload_v<T>
    size_t erase_before(T x_threshold)
    {
        return erase_before_f64(static_cast<double>(x_threshold));
    }
    /// @brief Remove points with x above a threshold; returns how many were removed.
    virtual size_t erase_after(float /*x_threshold*/) { return 0; }
    /// @brief Remove points with x above an absolute double x; see erase_before(float).
    template <typename T>
        requires detail::wants_f64_overload_v<T>
    size_t erase_after(T x_threshold)
    {
        return erase_after_f64(static_cast<double>(x_threshold));
    }
    /// @brief Drop the oldest points so at most @p max_points remain.
    virtual size_t trim_to_max_points(size_t /*max_points*/) { return 0; }
    /// @brief Approximate memory used by the series data.
    virtual size_t memory_bytes() const { return 0; }

   protected:
    Series& apply_format_string(std::string_view fmt);

    // Double-precision streaming hooks behind the append()/erase_*() templates.
    // The defaults convert to the float forms relative to the current offsets;
    // LineSeries / ScatterSeries also pick the first origin and stay
    // consistent in thread-safe mode.
    virtual void   append_f64(double x, double y);
    virtual size_t erase_before_f64(double x_threshold);
    virtual size_t erase_after_f64(double x_threshold);

    std::string          label_;
    Color                color_            = colors::blue;
    int                  auto_color_index_ = -1;     ///< palette slot, -1 = explicit colour
    char                 color_letter_     = '\0';   ///< format-string colour letter, '\0' = none
    PlotStyle            style_;                     ///< line/marker style, sizes, opacity
    bool                 visible_                 = true;
    double               x_offset_                = 0.0;
    double               y_offset_                = 0.0;
    bool                 excluded_from_autoscale_ = false;
    bool                 show_in_legend_          = true;
    bool                 is_reference_line_       = false;
    std::string          data_binding_;   ///< layout binding URI, "" = none
    SeriesDirtyFlag      dirty_{true};
    static std::uint64_t next_instance_id();
    std::uint64_t        instance_id_  = next_instance_id();   // not copied: see instance_id()
    EventSystem*         event_system_ = nullptr;
    AxesBase*            owning_axes_  = nullptr;

    /// Thread-safe data buffering (opt-in).
    bool                                                         thread_safe_ = false;
    std::unique_ptr<PendingSeriesData, PendingSeriesDataDeleter> pending_;
};

/// @brief A polyline through (x, y) points, with optional markers and dash patterns.
class LineSeries : public Series
{
   public:
    LineSeries() = default;
    /// @brief Construct from x/y data (copied).
    LineSeries(std::span<const float> x, std::span<const float> y);
    /// @brief Construct from double x/y data; see set_x(std::span<const double>).
    template <typename = void>
    LineSeries(std::span<const double> x, std::span<const double> y)
    {
        set_x_f64(x);
        set_y_f64(y);
    }

    /// @brief Replace the x data.
    LineSeries& set_x(std::span<const float> x);
    /// @brief Replace the y data.
    LineSeries& set_y(std::span<const float> y);

    /// @brief Replace the x data from doubles without losing precision.
    ///
    /// When the values are large compared to their spread (e.g. Unix
    /// timestamps, or 1e7 + small variations), a data origin near the values
    /// is stored in x_offset() and x_data() holds float offsets from it, so
    /// the plot, axis limits, ticks and readouts keep full precision.
    /// Otherwise x_offset() is set to 0 and x_data() holds the plain values.
    /// (A template only so that an existing call such as set_x({}) still
    /// picks the float overload.)
    template <typename = void>
    LineSeries& set_x(std::span<const double> x)
    {
        set_x_f64(x);
        return *this;
    }
    /// @brief Replace the y data from doubles; see set_x(std::span<const double>).
    template <typename = void>
    LineSeries& set_y(std::span<const double> y)
    {
        set_y_f64(y);
        return *this;
    }
    /// @brief Append one point; see Series::append(float, float) and the
    /// double-precision Series::append(double, double).
    using Series::append;
    void append(float x, float y) override;

    /// @brief Set the line width in pixels.
    LineSeries& width(float w)
    {
        line_width_ = w;
        dirty_      = true;
        return *this;
    }
    /// @brief Line width in pixels.
    float width() const { return line_width_; }

    /// @brief How consecutive points are connected: straight segments
    /// (default) or steps (pre / mid / post, like matplotlib's drawstyle).
    /// Markers, hover and picking stay on the data points.
    LineSeries& draw_style(DrawStyle s)
    {
        draw_style_ = s;
        dirty_      = true;
        return *this;
    }
    DrawStyle draw_style() const { return draw_style_; }

    /// @brief How the line is drawn when it has far more visible points than
    /// pixel columns.  Auto (default) keeps the first, last, lowest and highest
    /// point of every pixel column, which draws the same picture from far fewer
    /// points; Density draws every point translucently so the overlap shows
    /// where the data is dense; Exact always draws every point.
    LineSeries& dense_mode(DenseLineMode m)
    {
        dense_mode_ = m;
        dirty_      = true;
        return *this;
    }
    DenseLineMode dense_mode() const { return dense_mode_; }

    std::span<const float> x_data() const { return x_; }
    std::span<const float> y_data() const { return y_; }
    size_t                 point_count() const { return std::min(x_.size(), y_.size()); }
    bool                   x_is_sorted() const { return x_sorted_; }

    /// Remove all points with x < x_threshold.  Assumes x is sorted ascending.
    /// Returns the number of points removed.  A double threshold is an
    /// absolute x value (see Series::erase_before).
    using Series::erase_before;
    size_t erase_before(float x_threshold) override;

    /// Remove all points with x > x_threshold.  Assumes x is sorted ascending.
    using Series::erase_after;
    size_t erase_after(float x_threshold) override;

    /// Drop oldest points until at most max_points remain (FIFO).
    size_t trim_to_max_points(size_t max_points) override;

    /// Estimated memory consumption in bytes (x + y vectors).
    size_t memory_bytes() const override { return x_.size() * 2 * sizeof(float); }

    // Bring base-class getters into scope (setters below would otherwise hide them)
    using Series::color;
    using Series::label;
    using Series::line_style;
    using Series::marker_size;
    using Series::marker_style;
    using Series::opacity;

    // Re-declare fluent setters with correct return type
    LineSeries& label(const std::string& lbl)
    {
        Series::label(lbl);
        return *this;
    }
    LineSeries& color(const Color& c)
    {
        Series::color(c);
        return *this;
    }
    LineSeries& line_style(LineStyle s)
    {
        Series::line_style(s);
        return *this;
    }
    LineSeries& marker_style(MarkerStyle s)
    {
        Series::marker_style(s);
        return *this;
    }
    LineSeries& marker_size(float s)
    {
        Series::marker_size(s);
        return *this;
    }
    LineSeries& opacity(float o)
    {
        Series::opacity(o);
        return *this;
    }

    /// @brief Apply a MATLAB-style format string (e.g. "r--o").
    LineSeries& format(std::string_view fmt);

    /// Thread-safe commit override.
    bool commit_pending() override;

   protected:
    void   append_f64(double x, double y) override;
    size_t erase_before_f64(double x_threshold) override;
    size_t erase_after_f64(double x_threshold) override;

   private:
    void set_x_f64(std::span<const double> x);
    void set_y_f64(std::span<const double> y);

    std::vector<float> x_;
    std::vector<float> y_;
    float              line_width_ = 2.0f;
    bool               x_sorted_   = true;
    DrawStyle          draw_style_ = DrawStyle::Default;
    DenseLineMode      dense_mode_ = DenseLineMode::Auto;
};

/// @brief Individual markers at (x, y) points, optionally coloured per point through a colormap.
class ScatterSeries : public Series
{
   public:
    ScatterSeries() = default;
    /// @brief Construct from x/y data (copied).
    ScatterSeries(std::span<const float> x, std::span<const float> y);
    /// @brief Construct from double x/y data; see set_x(std::span<const double>).
    template <typename = void>
    ScatterSeries(std::span<const double> x, std::span<const double> y)
    {
        set_x_f64(x);
        set_y_f64(y);
    }

    /// @brief Replace the x data.
    ScatterSeries& set_x(std::span<const float> x);
    /// @brief Replace the y data.
    ScatterSeries& set_y(std::span<const float> y);

    /// @brief Replace the x data from doubles without losing precision.
    ///
    /// When the values are large compared to their spread (e.g. Unix
    /// timestamps, or 1e7 + small variations), a data origin near the values
    /// is stored in x_offset() and x_data() holds float offsets from it, so
    /// the plot, axis limits, ticks and readouts keep full precision.
    /// Otherwise x_offset() is set to 0 and x_data() holds the plain values.
    /// (A template only so that an existing call such as set_x({}) still
    /// picks the float overload.)
    template <typename = void>
    ScatterSeries& set_x(std::span<const double> x)
    {
        set_x_f64(x);
        return *this;
    }
    /// @brief Replace the y data from doubles; see set_x(std::span<const double>).
    template <typename = void>
    ScatterSeries& set_y(std::span<const double> y)
    {
        set_y_f64(y);
        return *this;
    }
    /// @brief Append one point; see Series::append(float, float) and the
    /// double-precision Series::append(double, double).
    using Series::append;
    void append(float x, float y) override;

    /// @brief Set the marker size in pixels.
    ScatterSeries& size(float s)
    {
        point_size_ = s;
        dirty_      = true;
        return *this;
    }
    /// @brief Marker size in pixels.
    float size() const { return point_size_; }

    std::span<const float> x_data() const { return x_; }
    std::span<const float> y_data() const { return y_; }
    size_t                 point_count() const { return std::min(x_.size(), y_.size()); }
    bool                   x_is_sorted() const { return x_sorted_; }

    // Bring base-class getters into scope (setters below would otherwise hide them)
    using Series::color;
    using Series::label;
    using Series::line_style;
    using Series::marker_size;
    using Series::marker_style;
    using Series::opacity;

    // Re-declare fluent setters with correct return type
    ScatterSeries& label(const std::string& lbl)
    {
        Series::label(lbl);
        return *this;
    }
    ScatterSeries& color(const Color& c)
    {
        Series::color(c);
        return *this;
    }
    ScatterSeries& line_style(LineStyle s)
    {
        Series::line_style(s);
        return *this;
    }
    ScatterSeries& marker_style(MarkerStyle s)
    {
        Series::marker_style(s);
        return *this;
    }
    ScatterSeries& marker_size(float s)
    {
        Series::marker_size(s);
        return *this;
    }
    ScatterSeries& opacity(float o)
    {
        Series::opacity(o);
        return *this;
    }

    /// @brief Apply a MATLAB-style format string (e.g. "ro").
    ScatterSeries& format(std::string_view fmt);

    // ── Colormap support ────────────────────────────────────────────────
    /// Set per-point color values (one float per point).  Values are mapped
    /// through the active colormap to produce per-point colors.
    ScatterSeries& color_values(std::span<const float> values);

    /// Set the colormap type used to map color_values to RGBA (keeps colormap_reversed()).
    ScatterSeries& colormap(ColormapType cm)
    {
        colormap_ = Colormap(cm, colormap_.is_reversed());
        dirty_    = true;
        return *this;
    }
    /// Set the colormap: built-in, reversed or user (Colormap::from_colors).
    ScatterSeries& colormap(const Colormap& cm)
    {
        colormap_ = cm;
        dirty_    = true;
        return *this;
    }
    /// Set the colormap by matplotlib name ("viridis", "RdBu_r"); unknown names give None.
    ScatterSeries& colormap(const std::string& name)
    {
        return colormap(Colormap::from_name(name).value_or(Colormap{}));
    }
    ColormapType    colormap() const { return colormap_.type(); }
    const Colormap& cmap() const { return colormap_; }

    /// Reverse the colormap (high values take the low end), like matplotlib's "_r" maps.
    ScatterSeries& colormap_reversed(bool reversed)
    {
        colormap_ = colormap_.reversed(reversed);
        dirty_    = true;
        return *this;
    }
    bool colormap_reversed() const { return colormap_.is_reversed(); }

    /// Set the colormap value range [min, max]. Values outside this range
    /// are clamped. When not set, uses the data range of color_values_.
    ScatterSeries& colormap_range(float min_val, float max_val)
    {
        colormap_min_ = min_val;
        colormap_max_ = max_val;
        colormap_set_ = true;
        dirty_        = true;
        return *this;
    }
    // Drop a manual range and fall back to the data range of color_values_.
    void clear_colormap_range();

    /// Access per-point color values (one float per point).
    std::span<const float> color_values_data() const { return color_values_; }
    bool                   has_colormap() const
    {
        return !colormap_.is_none() && color_values_.size() == x_.size() && x_.size() == y_.size()
               && !x_.empty();
    }
    float colormap_min() const { return colormap_min_; }
    float colormap_max() const { return colormap_max_; }
    bool  colormap_range_set() const { return colormap_set_; }

    /// Thread-safe commit override.
    bool commit_pending() override;

   protected:
    void append_f64(double x, double y) override;

   private:
    void set_x_f64(std::span<const double> x);
    void set_y_f64(std::span<const double> y);

    std::vector<float> x_;
    std::vector<float> y_;
    float              point_size_ = 6.0f;   // default marker diameter in pixels
    bool               x_sorted_   = true;
    // Colormap support
    std::vector<float> color_values_;
    Colormap           colormap_;
    float              colormap_min_ = 0.0f;
    float              colormap_max_ = 1.0f;
    bool               colormap_set_ = false;

    // Derive colormap_min_/colormap_max_ from the finite color_values_.
    void recompute_colormap_range();
};

}   // namespace spectra

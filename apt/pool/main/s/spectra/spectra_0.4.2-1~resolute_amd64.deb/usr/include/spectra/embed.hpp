#pragma once

// ─── Spectra Embedding API ──────────────────────────────────────────────────
//
// Render Spectra plots into a host application's GUI (Qt, GTK, game engines)
// without Spectra creating any OS windows.
//
// Two rendering modes:
//   1. CPU readback  — render_to_buffer() writes RGBA pixels to caller's buffer
//   2. Vulkan interop — render_to_image() (EXPERIMENTAL, not implemented yet:
//      always returns false; use render_to_buffer())
//
// Usage (CPU readback — works with QImage, GdkPixbuf, any CPU-composited UI):
//
//   spectra::EmbedSurface surface({800, 600});
//   auto& fig = surface.figure();
//   auto& ax  = fig.subplot(1, 1, 1);
//   ax.line(x, y);
//
//   std::vector<uint8_t> pixels(800 * 600 * 4);
//   surface.render_to_buffer(pixels.data());
//   // ... blit pixels into your UI widget ...
//
// Usage (Vulkan interop — planned zero-copy path; NOT functional yet):
//
//   spectra::EmbedSurface surface({800, 600, 1, true});
//   auto& fig = surface.figure();
//   ...
//   spectra::VulkanInteropInfo interop;
//   interop.target_image      = my_vk_image;
//   interop.format            = VK_FORMAT_R8G8B8A8_UNORM;
//   interop.ready_semaphore   = my_ready_sem;
//   interop.finished_semaphore = my_done_sem;
//   surface.render_to_image(interop);
//
// Input forwarding (host translates its events → Spectra input):
//
//   surface.inject_mouse_move(x, y);
//   surface.inject_mouse_button(0, true, 0);  // left press
//   surface.inject_scroll(0, 1.0);
//
// ─────────────────────────────────────────────────────────────────────────────

#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <spectra/figure.hpp>
#include <spectra/fwd.hpp>

namespace spectra
{

// ─── Configuration ──────────────────────────────────────────────────────────

struct EmbedConfig
{
    uint32_t width  = 800;
    uint32_t height = 600;
    uint32_t msaa   = 1;   // 1 = no MSAA, 4 = 4x MSAA

    // Reserved for zero-copy Vulkan interop via render_to_image(), which is
    // experimental and not implemented yet.  Leave false (default) and use
    // render_to_buffer().
    bool enable_vulkan_interop = false;

    // DPI scale factor (1.0 = 96 DPI, 2.0 = Retina/HiDPI): framebuffer pixels
    // per logical pixel.  Text, ticks, margins and line widths scale with it.
    float dpi_scale = 1.0f;

    // Background color alpha. Set to 0.0f for transparent background
    // (useful for compositing over host content).
    float background_alpha = 1.0f;

    // Theme name ("dark", "night", or "light"). Default: "night".
    std::string theme = "night";

    // UI chrome visibility (only effective when built with SPECTRA_USE_IMGUI).
    // When ImGui is not available, these are ignored and only the raw plot is rendered.
    // Default: ALL chrome OFF — embed renders canvas-only with Spectra theme colors.
    // Set individual flags to true to opt-in to specific UI elements.
    bool show_imgui_chrome = false;   // Master switch: enable ImGui UI pipeline
    bool show_command_bar  = false;   // Top command/menu bar
    bool show_status_bar   = false;   // Bottom status bar
    bool show_nav_rail     = false;   // Left navigation rail
    bool show_inspector    = false;   // Right inspector panel
    bool show_legend       = true;    // Series legend overlay (rendered by Vulkan, not ImGui)
    bool show_crosshair    = true;    // Crosshair + cursor readout

    // Fluent builder for EmbedConfig.  Defined out-of-line below.
    //
    //   auto cfg = EmbedConfig::Builder()
    //                  .size(1280, 720)
    //                  .theme("dark")
    //                  .with_inspector()
    //                  .without_legend()
    //                  .build();
    class Builder;
};

class EmbedConfig::Builder
{
   public:
    Builder() = default;

    Builder& size(uint32_t w, uint32_t h)
    {
        cfg_.width  = w;
        cfg_.height = h;
        return *this;
    }
    Builder& theme(std::string name)
    {
        cfg_.theme = std::move(name);
        return *this;
    }
    Builder& dpi_scale(float s)
    {
        cfg_.dpi_scale = s;
        return *this;
    }
    Builder& msaa(uint32_t samples)
    {
        cfg_.msaa = samples > 0 ? samples : 1;
        return *this;
    }
    Builder& background_alpha(float a)
    {
        cfg_.background_alpha = a;
        return *this;
    }
    Builder& transparent()
    {
        cfg_.background_alpha = 0.0f;
        return *this;
    }
    Builder& vulkan_interop(bool enabled = true)
    {
        cfg_.enable_vulkan_interop = enabled;
        return *this;
    }
    Builder& with_command_bar(bool v = true)
    {
        cfg_.show_command_bar = v;
        cfg_.show_imgui_chrome |= v;
        return *this;
    }
    Builder& with_status_bar(bool v = true)
    {
        cfg_.show_status_bar = v;
        cfg_.show_imgui_chrome |= v;
        return *this;
    }
    Builder& with_nav_rail(bool v = true)
    {
        cfg_.show_nav_rail = v;
        cfg_.show_imgui_chrome |= v;
        return *this;
    }
    Builder& with_inspector(bool v = true)
    {
        cfg_.show_inspector = v;
        cfg_.show_imgui_chrome |= v;
        return *this;
    }
    Builder& with_imgui_chrome(bool v = true)
    {
        cfg_.show_imgui_chrome = v;
        return *this;
    }
    Builder& with_legend(bool v = true)
    {
        cfg_.show_legend = v;
        return *this;
    }
    Builder& without_legend()
    {
        cfg_.show_legend = false;
        return *this;
    }
    Builder& with_crosshair(bool v = true)
    {
        cfg_.show_crosshair = v;
        return *this;
    }
    Builder& without_crosshair()
    {
        cfg_.show_crosshair = false;
        return *this;
    }

    EmbedConfig build() const { return cfg_; }

   private:
    EmbedConfig cfg_{};
};

// Vulkan interop target for render_to_image() (EXPERIMENTAL, not implemented
// yet).  The host would provide these so Spectra renders directly
// into the host's VkImage.  Both semaphores are optional (VK_NULL_HANDLE
// to skip synchronization when the host manages barriers manually).
struct VulkanInteropInfo
{
    uint64_t target_image       = 0;    // VkImage (as uint64_t to avoid vulkan.h in public header)
    uint32_t format             = 37;   // VK_FORMAT_R8G8B8A8_UNORM
    uint64_t ready_semaphore    = 0;    // Host signals when image is available for writing
    uint64_t finished_semaphore = 0;    // Spectra signals when render is complete
    uint32_t width              = 0;    // Target image width  (0 = use surface width)
    uint32_t height             = 0;    // Target image height (0 = use surface height)
};

// ─── Callbacks ──────────────────────────────────────────────────────────────

// Cursor shape that the host should display.
enum class CursorShape
{
    Arrow,
    Crosshair,
    Hand,
    ResizeH,
    ResizeV,
    ResizeAll,
};

using RedrawCallback       = std::function<void()>;
using CursorChangeCallback = std::function<void(CursorShape)>;
using TooltipCallback      = std::function<void(const std::string& text, float x, float y)>;

// Invoked once per update(dt) step with the cumulative elapsed time and the
// delta of the current step.  Use for live data streaming / animation.
using FrameCallback = std::function<void(float time_sec, float dt_sec)>;

// ── Interactive event callbacks ─────────────────────────────────────────────
// series_index is the index of the series within its axes; point_index is the
// index of the data point within the series.  axes_index is the index of the
// axes within the figure.
using PointSelectedCallback = std::function<
    void(int axes_index, int series_index, std::size_t point_index, double x, double y)>;
using SeriesSelectedCallback = std::function<void(int axes_index, int series_index)>;
// Fired when the hovered (nearest) data point changes.  series_index < 0 means
// the cursor moved away from any series.
using HoverCallback = std::function<
    void(int axes_index, int series_index, std::size_t point_index, double x, double y)>;
// Fired when the visible data range (xlim/ylim) of the active axes changes via
// pan/zoom/auto-fit.
using ViewChangedCallback = std::function<void(double xmin, double xmax, double ymin, double ymax)>;

// ─── Mouse button constants (match GLFW) ────────────────────────────────────

namespace embed
{
inline constexpr int MOUSE_BUTTON_LEFT   = 0;
inline constexpr int MOUSE_BUTTON_RIGHT  = 1;
inline constexpr int MOUSE_BUTTON_MIDDLE = 2;

inline constexpr int MOD_SHIFT   = 0x0001;
inline constexpr int MOD_CONTROL = 0x0002;
inline constexpr int MOD_ALT     = 0x0004;
inline constexpr int MOD_SUPER   = 0x0008;

// Key constants (match GLFW key codes)
inline constexpr int KEY_ESCAPE    = 256;
inline constexpr int KEY_ENTER     = 257;
inline constexpr int KEY_TAB       = 258;
inline constexpr int KEY_BACKSPACE = 259;
inline constexpr int KEY_DELETE    = 261;
inline constexpr int KEY_RIGHT     = 262;
inline constexpr int KEY_LEFT      = 263;
inline constexpr int KEY_DOWN      = 264;
inline constexpr int KEY_UP        = 265;
inline constexpr int KEY_HOME      = 268;
inline constexpr int KEY_END       = 269;

// Letter keys (A-Z = 65-90)
inline constexpr int KEY_A = 65;
inline constexpr int KEY_C = 67;
inline constexpr int KEY_G = 71;
inline constexpr int KEY_Q = 81;
inline constexpr int KEY_R = 82;
inline constexpr int KEY_S = 83;
inline constexpr int KEY_Z = 90;

// Number keys (0-9 = 48-57)
inline constexpr int KEY_0 = 48;
inline constexpr int KEY_9 = 57;

// Space
inline constexpr int KEY_SPACE = 32;

// Action constants
inline constexpr int ACTION_RELEASE = 0;
inline constexpr int ACTION_PRESS   = 1;
inline constexpr int ACTION_REPEAT  = 2;
}   // namespace embed

// ─── EmbedSurface ───────────────────────────────────────────────────────────

class EmbedSurface
{
   public:
    explicit EmbedSurface(const EmbedConfig& config = {});
    ~EmbedSurface();

    // Non-copyable
    EmbedSurface(const EmbedSurface&)            = delete;
    EmbedSurface& operator=(const EmbedSurface&) = delete;

    // Move-constructible
    EmbedSurface(EmbedSurface&&) noexcept;
    EmbedSurface& operator=(EmbedSurface&&) noexcept;

    // Returns true if the surface initialized successfully.
    bool is_valid() const;

    // ── Figure management ───────────────────────────────────────────────

    // Create a new figure on this surface.
    Figure& figure(const FigureConfig& cfg = {});

    // Get the currently active figure (nullptr if none).
    Figure*       active_figure();
    const Figure* active_figure() const;

    // Set the active figure by pointer.
    void set_active_figure(Figure* fig);

    // Access the figure registry.
    FigureRegistry& figure_registry();

    // ── Rendering ───────────────────────────────────────────────────────

    // Resize the offscreen framebuffer. Call when the host widget changes size.
    // Returns false on failure (zero dimensions, Vulkan error).
    bool resize(uint32_t width, uint32_t height);

    // CPU readback mode: render one frame and write RGBA pixels into the
    // caller's buffer.  Buffer must be at least width() * height() * 4 bytes.
    // Returns false on render or readback failure.
    bool render_to_buffer(uint8_t* out_rgba);

    // EXPERIMENTAL / NOT IMPLEMENTED: zero-copy rendering into a
    // host-provided VkImage.  The entry point exists to reserve the API, but
    // it currently always returns false (logging a warning) and renders
    // nothing.  Use render_to_buffer() instead.
    bool render_to_image(const VulkanInteropInfo& target);

    // ── Input forwarding ────────────────────────────────────────────────
    // Host application translates its native events and calls these.
    // Coordinates are in pixel space relative to the surface's top-left.
    // Button/key/mod constants are in the spectra::embed namespace above.

    void inject_mouse_move(float x, float y);
    void inject_mouse_button(int button, int action, int mods, float x, float y);
    void inject_scroll(float dx, float dy, float cursor_x, float cursor_y);
    void inject_key(int key, int action, int mods);
    void inject_char(unsigned int codepoint);

    // Advance internal animations by dt seconds.
    // Call once per host frame to keep pan inertia, zoom animations, etc. alive.
    void update(float dt);

    // ── Properties ──────────────────────────────────────────────────────

    uint32_t width() const;
    uint32_t height() const;
    // Framebuffer pixels per logical pixel.  Above 1 the figure is laid out at
    // width/scale x height/scale and drawn scale times larger, so text, ticks
    // and lines keep their apparent size and stay sharp (HiDPI).  Input
    // coordinates stay in framebuffer pixels.
    float dpi_scale() const;
    void  set_dpi_scale(float scale);

    // Data coordinates under the pointer (last inject_mouse_move / button),
    // when it is over a 2D axes.  Returns false otherwise.
    bool cursor_data(double& data_x, double& data_y) const;

    float background_alpha() const;
    void  set_background_alpha(float alpha);

    // Theme of this surface ("dark", "night", "light").  Applies to this
    // surface's own ThemeManager only — other surfaces are unaffected.
    void        set_theme(const std::string& name);
    std::string theme() const;

    // ── UI chrome visibility ────────────────────────────────────────────
    // Setters persist state in the surface config and route to the live
    // LayoutManager / overlays when an ImGui build is active.  Getters
    // reflect the current configured state.

    void set_show_command_bar(bool visible);
    void set_show_status_bar(bool visible);
    void set_show_nav_rail(bool visible);
    void set_show_inspector(bool visible);
    void set_show_legend(bool visible);
    void set_show_crosshair(bool visible);

    bool show_command_bar() const;
    bool show_status_bar() const;
    bool show_nav_rail() const;
    bool show_inspector() const;
    bool show_legend() const;
    bool show_crosshair() const;

    // ── Callbacks ───────────────────────────────────────────────────────

    // Called when Spectra's internal state changes and a repaint is needed.
    // Use this for on-demand rendering instead of constant polling.
    void set_redraw_callback(RedrawCallback cb);

    // Called when the cursor shape should change (e.g. crosshair during hover).
    void set_cursor_change_callback(CursorChangeCallback cb);

    // Called when a tooltip should be shown/hidden.
    void set_tooltip_callback(TooltipCallback cb);

    // Per-step frame callback.  Invoked inside update(dt) with the
    // cumulative elapsed time and the current step delta.  Use for live data
    // streaming and animation.  Pass nullptr / call clear_frame_callback() to
    // remove.  reset_frame_clock() rewinds the cumulative time to zero.
    void  set_frame_callback(FrameCallback cb);
    void  clear_frame_callback();
    void  reset_frame_clock();
    float frame_time() const;

    // ── Interactive event callbacks ─────────────────────────────────────
    // Fired when the user selects a concrete data point (left-click near it).
    void set_on_point_selected(PointSelectedCallback cb);
    // Fired when the user selects a series (left-click near it).
    void set_on_series_selected(SeriesSelectedCallback cb);
    // Fired when the hovered/nearest data point changes.
    void set_on_hover(HoverCallback cb);
    // Fired when the visible data range of the active axes changes.
    void set_on_view_changed(ViewChangedCallback cb);

    // ── Advanced: Vulkan device sharing ─────────────────────────────────
    // For advanced integrations where the host already has a Vulkan device.

    // Access Spectra's Vulkan internals (for device sharing, interop setup).
    Backend*  backend();
    Renderer* renderer();

   private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

}   // namespace spectra

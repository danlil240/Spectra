#pragma once

#include <cstdint>
#include <span>
#include <spectra/color.hpp>
#include <string>
#include <vector>

namespace spectra
{

// Forward declarations for SVG / PDF export
class Figure;

class ImageExporter
{
   public:
    static bool write_png(const std::string& path,
                          const uint8_t*     rgba_data,
                          uint32_t           width,
                          uint32_t           height);

    static std::vector<uint8_t> write_png_to_memory(const uint8_t* rgba_data,
                                                    uint32_t       width,
                                                    uint32_t       height);
};

// Colours of the non-data parts of an SVG export (background, grid, axes,
// text, legend).  The defaults match the built-in "light" theme; the app fills
// this from the active theme so an export looks like the on-screen plot.
struct SvgStyle
{
    Color       background     = {0.969f, 0.980f, 1.000f, 1.0f};   ///< figure + plot area
    Color       grid_major     = {0.32f, 0.40f, 0.48f, 0.24f};
    Color       grid_minor     = {0.32f, 0.40f, 0.48f, 0.10f};
    Color       axis_line      = {0.08f, 0.16f, 0.23f, 0.78f};   ///< border, tick marks, 3D box
    Color       tick_label     = {0.125f, 0.196f, 0.278f, 1.0f};
    Color       text_primary   = {0.063f, 0.125f, 0.200f, 1.0f};   ///< titles; 'k'/'w' series remap
    Color       text_secondary = {0.200f, 0.282f, 0.373f, 1.0f};   ///< axis labels, legend text
    Color       legend_bg      = {0.973f, 0.984f, 1.000f, 1.0f};
    Color       legend_border  = {0.61f, 0.72f, 0.82f, 0.44f};
    std::string font_family    = "Inter, 'Helvetica Neue', Arial, sans-serif";

    /// Layout (legend boxes, label fitting, tick spacing) is computed with Inter's
    /// advances.  When true, each text whose glyphs Inter covers carries
    /// textLength + lengthAdjust="spacingAndGlyphs", so a viewer that sets it in a
    /// fallback font (or another font_family) still matches that layout.
    bool fit_text_length = true;

    /// Embed the glyphs of Inter the document uses (a subset TrueType font in an
    /// @font-face named "Inter"), so viewers without Inter installed render the
    /// exact face.  Off by default: it adds roughly 30-60 KB to the file.
    bool embed_font = false;

    /// Leave out the background rectangle (a transparent page).  `background`
    /// still decides the ink colours that must contrast with it.
    bool transparent_background = false;
};

class SvgExporter
{
   public:
    // Write a Figure to an SVG file. Traverses Figure→Axes→Series hierarchy
    // and emits SVG elements directly, bypassing the GPU pipeline.
    // 3D axes are projected with their camera and painter-sorted.
    // Without an SvgStyle the light-theme chrome is used, except that a
    // FigureStyle::background_override supplies the background (and dark ink
    // when that background is dark).
    static bool write_svg(const std::string& path, const Figure& figure);
    static bool write_svg(const std::string& path, const Figure& figure, const SvgStyle& style);

    // Write SVG to a string instead of a file.
    static std::string to_string(const Figure& figure);
    static std::string to_string(const Figure& figure, const SvgStyle& style);
};

// Vector PDF (1.4) export: the same drawing as SvgExporter (chrome colours from an
// SvgStyle; fit_text_length / embed_font do not apply), one page per figure at
// 96 dpi (1 px = 0.75 pt), text set in an embedded Inter subset so it stays
// selectable and searchable.  As for SVG, the caller computes each figure's layout.
class PdfExporter
{
   public:
    static bool write_pdf(const std::string& path, const Figure& figure);
    static bool write_pdf(const std::string& path, const Figure& figure, const SvgStyle& style);
    // One page per figure (in order), each with its default style.
    static bool write_pdf(const std::string& path, std::span<const Figure* const> figures);

    // The PDF document as bytes.
    static std::string to_string(const Figure& figure);
    static std::string to_string(const Figure& figure, const SvgStyle& style);
};

#ifdef SPECTRA_USE_FFMPEG
class VideoExporter
{
   public:
    struct Config
    {
        std::string output_path;
        uint32_t    width   = 1280;
        uint32_t    height  = 720;
        float       fps     = 60.0f;
        std::string codec   = "libx264";
        std::string pix_fmt = "yuv420p";
    };

    explicit VideoExporter(const Config& config);
    ~VideoExporter();

    VideoExporter(const VideoExporter&)            = delete;
    VideoExporter& operator=(const VideoExporter&) = delete;

    bool write_frame(const uint8_t* rgba_data);
    void finish();

    bool is_open() const { return pipe_ != nullptr; }

   private:
    Config config_;
    FILE*  pipe_ = nullptr;
};
#endif   // SPECTRA_USE_FFMPEG

}   // namespace spectra


####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was spectraConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)

# Build configuration of this Spectra package (informational).
set(spectra_USE_EIGEN   OFF)
set(spectra_USE_GLFW    ON)
set(spectra_USE_SDL3    OFF)
set(spectra_SYSTEM_GLFW OFF)
set(spectra_SYSTEM_SDL3 OFF)

# Spectra always requires Vulkan.
find_dependency(Vulkan)

# Eigen3 is a PUBLIC dependency only when Spectra was built with
# SPECTRA_USE_EIGEN (vector adapters in spectra/eigen.hpp).
if(spectra_USE_EIGEN)
    find_dependency(Eigen3)
endif()

# A system GLFW / SDL3 is linked into the static library and has to be
# re-found here; bundled copies are part of spectraTargets.cmake instead.
if(spectra_SYSTEM_GLFW)
    find_dependency(glfw3 3.3)
endif()
if(spectra_SYSTEM_SDL3)
    find_dependency(SDL3 3.2)
endif()

# Threads is needed by the bundled GLFW / SDL3 static libraries and is cheap
# to look up (always available), so it is found unconditionally.
find_dependency(Threads)

# Import targets (includes spectra::glfw when GLFW was bundled via FetchContent)
if(NOT TARGET spectra::spectra)
    include("${CMAKE_CURRENT_LIST_DIR}/spectraTargets.cmake")
endif()

check_required_components(spectra)
